#!/usr/bin/env python3
"""Reproduce every number in the paper's pilot tables from the published raw outputs (no GPU, about one minute).

Steps:
  1. verify the integrity of the bundled InjecAgent files and the published raw outputs (SHA-256)
  2. recompute the statistics           -> reproduced/summary.json, summary.csv
  3. rebuild Tables 5 and 6 and the plots -> reproduced/tables.md, fig3_*.pdf/png, fig4_*.pdf/png
  4. rerun the fallback sensitivity analysis -> reproduced/sensitivity_fallback.json
     and the descriptive counts of Sections 6.1 and 6.6 -> reproduced/descriptives.json
  5. check that the regenerated files are byte-identical to those in results/

Usage: python3 reproduce.py
Exit status 0 means every check passed.
"""
import hashlib, os, subprocess, sys

REPO = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.join(REPO, "pipeline")
RESULTS = os.path.join(REPO, "results")
RAW = [os.path.join(RESULTS, "raw", m) for m in ("llama3.1-8b-ctx8k", "qwen2.5-7b-ctx8k")]
OUT = os.path.join(REPO, "reproduced")
COMPARED = ["summary.json", "summary.csv", "tables.md", "sensitivity_fallback.json", "descriptives.json"]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def check_sums(sums_file, base):
    bad = 0
    for line in open(sums_file):
        digest, name = line.split(maxsplit=1)
        name = name.strip().lstrip("*")
        path = os.path.join(base, name)
        if not os.path.exists(path) or sha256(path) != digest:
            print(f"  MISMATCH  {name}")
            bad += 1
    return bad


def step(title, cmd):
    print(f"\n{title}")
    subprocess.run([sys.executable] + cmd, check=True, stdout=subprocess.DEVNULL)


def main():
    print("1. Integrity of input files")
    bad = check_sums(os.path.join(REPO, "data", "injecagent", "SHA256SUMS"), os.path.join(REPO, "data", "injecagent"))
    bad += check_sums(os.path.join(RESULTS, "SHA256SUMS"), RESULTS)
    if bad:
        sys.exit(f"{bad} file(s) differ from their published checksums; stop.")
    print("  all checksums match")
    os.makedirs(OUT, exist_ok=True)
    step("2. Statistics (analyze.py)", [os.path.join(PIPE, "analyze.py")] + RAW + ["--out", OUT])
    step("3. Tables and plots (make_report.py)", [os.path.join(PIPE, "make_report.py"), os.path.join(OUT, "summary.json")])
    step("4. Sensitivity analysis and descriptive counts", [os.path.join(PIPE, "sensitivity_fallback.py")] + RAW + ["--out", OUT])
    subprocess.run([sys.executable, os.path.join(PIPE, "describe_outputs.py")] + RAW + ["--out", OUT], check=True, stdout=subprocess.DEVNULL)
    print("\n5. Comparison with the published results")
    ok = True
    for name in COMPARED:
        same = sha256(os.path.join(OUT, name)) == sha256(os.path.join(RESULTS, name))
        ok &= same
        print(f"  {'identical' if same else 'DIFFERENT'}  {name}")
    print("  (plots are regenerated in reproduced/ but not compared byte for byte, because PDF files embed a timestamp)")
    if not ok:
        sys.exit("\nReproduction FAILED: see the files marked DIFFERENT. Check package versions against requirements.txt.")
    print("\nReproduction PASSED: every reported value regenerates exactly from the raw outputs.")


if __name__ == "__main__":
    main()
